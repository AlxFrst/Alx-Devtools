<?php
namespace compagnyname\iTop\Extension\Service;

class MyService
{

}